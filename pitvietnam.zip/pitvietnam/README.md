# PiT Viet Nam.

Build tools for the Landing Page

```
# To get started
npm start

# Static build
npm run build

# To deploy
npm run deploy
```
