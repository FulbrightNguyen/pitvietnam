import Anchor from './anchor';

const anchors = new Anchor();
anchors.add('h2');
window.ga('send', 'pageview');
