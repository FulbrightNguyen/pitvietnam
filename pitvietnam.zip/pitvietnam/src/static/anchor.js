/**
 * AnchorJS - v2.0.0 - 2015-10-31
 * https://github.com/bryanbraun/anchorjs
 * Copyright (c) 2015 Bryan Braun; Licensed MIT
 */

function AnchorJS(options) {
  var that = this;

  this.options = options || {};

  /**
   * Assigns options to the internal options object, and provides defaults.
   * @param {Object} opts - Options object
   */
  function _applyRemainingDefaultOptions(opts) {
    that.options.icon = that.options.hasOwnProperty('icon') ? opts.icon : '\ue9cb'; // Accepts characters (and also URLs?), like  '#', '¶', '❡', or '§'.
    that.options.visible = that.options.hasOwnProperty('visible') ? opts.visible : 'hover'; // Also accepts 'always'
    that.options.placement = that.options.hasOwnProperty('placement') ? opts.placement : 'right'; // Also accepts 'left'
    that.options.class = that.options.hasOwnProperty('class') ? opts.class : ''; // Accepts any class name.
    // Using Math.floor here will ensure the value is Number-cast and an integer.
    that.options.truncate = that.options.hasOwnProperty('truncate') ? Math.floor(opts.truncate) : 64; // Accepts any value that can be typecast to a number.
  }

  _applyRemainingDefaultOptions(options);

  /**
   * Add anchor links to page elements.
   * @param  {String} selector  A CSS selector for targeting the elements you wish to add anchor links to.
   * @return {this}             The AnchorJS object
   */
  this.add = function(selector) {
    var elements,
        elsWithIds,
        idList,
        elementID,
        i,
        index,
        count,
        tidyText,
        newTidyText,
        readableID,
        anchor;

    // We reapply options here because somebody may have overwritten the default options object when setting options.
    // For example, this overwrites all options but visible:
    //
    // anchors.options = { visible: 'always'; }
    _applyRemainingDefaultOptions(this.options);

    // Provide a sensible default selector, if none is given.
    if (!selector) {
      selector = 'h1, h2, h3, h4, h5, h6';
    } else if (typeof selector !== 'string') {
      throw new Error('The selector provided to AnchorJS was invalid.');
    }

    elements = document.querySelectorAll(selector);
    if (elements.length === 0) {
      return false;
    }

    // We produce a list of existing IDs so we don't generate a duplicate.
    elsWithIds = document.querySelectorAll('[id]');
    idList = [].map.call(elsWithIds, function assign(el) {
      return el.id;
    });

    for (i = 0; i < elements.length; i++) {

      if (elements[i].hasAttribute('id')) {
        elementID = elements[i].getAttribute('id');
      } else {
        tidyText = this.urlify(elements[i].textContent);

        // Compare our generated ID to existing IDs (and increment it if needed)
        // before we add it to the page.
        newTidyText = tidyText;
        count = 0;
        do {
          if (index !== undefined) {
            newTidyText = tidyText + '-' + count;
          }

          // .indexOf is only supported in IE9+.
          index = idList.indexOf(newTidyText);
          count += 1;
        } while (index !== -1);
        index = undefined;
        idList.push(newTidyText);

        // Assign it to our element.
        // Currently the setAttribute element is only supported in IE9 and above.
        elements[i].setAttribute('id', newTidyText);

        elementID = newTidyText;
      }

      readableID = elementID.replace(/-/g, ' ');

      // The following code builds the following DOM structure in a more effiecient (albeit opaque) way.
      // '<a class="anchorjs-link ' + this.options.class + '" href="#' + elementID + '" aria-label="Anchor link for: ' + readableID + '" data-anchorjs-icon="' + this.options.icon + '"></a>';
      anchor = document.createElement('a');
      anchor.className = 'anchorjs-link ' + this.options.class;
      anchor.href = '#' + elementID;
      anchor.setAttribute('aria-label', 'Anchor link for: ' + readableID);
      anchor.setAttribute('data-anchorjs-icon', this.options.icon);

      if (this.options.visible === 'always') {
        anchor.style.opacity = '1';
      }

      if (this.options.icon === '\ue9cb') {
        anchor.style.fontFamily = 'anchorjs-icons';
        anchor.style.fontStyle = 'normal';
        anchor.style.fontVariant = 'normal';
        anchor.style.fontWeight = 'normal';
        anchor.style.lineHeight = 1;

        // We set lineHeight = 1 here because the `anchorjs-icons` font family could otherwise affect the
        // height of the heading. This isn't the case for icons with `placement: left`, so we restore
        // line-height: inherit in that case, ensuring they remain positioned correctly. For more info,
        // see https://github.com/bryanbraun/anchorjs/issues/39.
        if (this.options.placement === 'left') {
          anchor.style.lineHeight = 'inherit';
        }
      }

      if (this.options.placement === 'left') {
        anchor.style.position = 'absolute';
        anchor.style.marginLeft = '-1em';
        anchor.style.paddingRight = '0.5em';
        elements[i].insertBefore(anchor, elements[i].firstChild);
      } else { // if the option provided is `right` (or anything else).
        anchor.style.paddingLeft = '0.375em';
        elements[i].appendChild(anchor);
      }
    }

    return this;
  };

  /**
   * Removes all anchorjs-links from elements targed by the selector.
   * @param  {String} selector  A CSS selector used to target elements containing anchor links.
   * @return {this}             The AnchorJS object
   */
  this.remove = function(selector) {
    var domAnchor,
        elements = document.querySelectorAll(selector);
    for (var i = 0; i < elements.length; i++) {
      domAnchor = elements[i].querySelector('.anchorjs-link');
      if (domAnchor) {
        elements[i].removeChild(domAnchor);
      }
    }
    return this;
  };

  /**
   * Urlify - Refine text so it makes a good ID.
   *
   * To do this, we remove apostrophes, replace nonsafe characters with hyphens,
   * remove extra hyphens, truncate, trim hyphens, and make lowercase.
   *
   * @param  {String} text - Any text. Usually pulled from the webpage element we are linking to.
   * @return {String}      - hyphen-delimited text for use in IDs and URLs.
   */
  this.urlify = function(text) {
    // Regex for finding the nonsafe URL characters (many need escaping): & +$,:;=?@"#{}|^~[`%!']./()*\
    var nonsafeChars = /[& +$,:;=?@"#{}|^~[`%!'\]\.\/\(\)\*\\]/g,
        urlText;

    if (!this.options.truncate) {
      _applyRemainingDefaultOptions(this.options);
    }

    // Note: we trim hyphens after truncating because truncating can cause dangling hyphens.
    // Example string:                                  // " ⚡ Don't forget: URL fragments should be i18n-friendly, hyphenated, short, and clean."
    urlText = text.replace(/\'/gi, '')                  // " ⚡ Dont forget: URL fragments should be i18n-friendly, hyphenated, short, and clean."
                  .replace(nonsafeChars, '-')           // "-⚡-Dont-forget--URL-fragments-should-be-i18n-friendly--hyphenated--short--and-clean-"
                  .replace(/-{2,}/g, '-')               // "-⚡-Dont-forget-URL-fragments-should-be-i18n-friendly-hyphenated-short-and-clean-"
                  .substring(0, this.options.truncate)  // "-⚡-Dont-forget-URL-fragments-should-be-i18n-friendly-hyphenated-"
                  .replace(/^-+|-+$/gm, '')             // "⚡-Dont-forget-URL-fragments-should-be-i18n-friendly-hyphenated"
                  .toLowerCase();                       // "⚡-dont-forget-url-fragments-should-be-i18n-friendly-hyphenated"

    return urlText;
  };
}

export default AnchorJS;
