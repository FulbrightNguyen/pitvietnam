import React from 'react';

import Video from './Video';

import 'thirdparties/css/jssocials.css';
import 'thirdparties/css/jssocials-theme-custom.css';
import 'thirdparties/css/style.css';

import styles from './Landing.scss';

import logoImg from 'images/pitvietnam_weblogo.png';
import logoDarkImg from 'images/logoDark.png';
import appleDownloadImg from 'images/downloads/apple.png';
import downloadMobImg from 'images/download-mob.png';
import featuresMobVideo from 'images/features-mob.mp4';
import homeScreenVideo from 'images/home-screen.mp4';
import chatIconImg from 'images/svg/chat.svg';

import web from 'images/services/web.png';
import app from 'images/services/app.png'
import sysadmin from 'images/services/sysadmin.png'
import devops from 'images/services/devops.png'

import webdesign from 'images/services/webdesign_service_pitvietnam.png';
import webadmin from 'images/services/webadmin_service_pitvietnam.png';

import webdesignPrice from 'images/services/pricelist_webdesign_pitvietnam.png';
import webdesignListDone from 'images/services/webdesignListDone.png';
import piTVietNamContact from 'images/services/pitvietnamContactImg.png';



import placeIconImg from 'images/svg/place.svg';
import calendarIconImg from 'images/svg/calendar.svg';
import pinIconImg from 'images/svg/pin.svg';
import upvoteIconImg from 'images/svg/upvote.svg';
import atIconImg from 'images/svg/at.svg';
import happyIconImg from 'images/svg/happy.svg';
import homeSlateImg from 'images/home.slate.jpg';
import chatSlateImg from 'images/chat.slate.jpg';

const navs = [
  { id: '#home', label: 'Trang chủ' },
  { id: '#intro', label: 'Giới thiệu' },
  { id: '#services1', label: 'Thiết kế Web' },
  { id: '#services2', label: 'Quản trị Web' },
  { id: '#pricelist', label: 'Bảng giá' },
  { id: '#projects', label: 'Dự án' },
  { id: '#contact', label: 'Liên hệ' }
  
];

const downloadButton = <a href="https://1pd8.app.link/app-store"><img src={appleDownloadImg} alt="Apple App Store" /></a>;

export default class Landing extends React.Component {
  static propTypes = {
    assetsByChunkName: React.PropTypes.object.isRequired,
  };

  render() {
    return (
      <body id="page-top" data-spy="scroll" data-target="#scrollspy-nav">
        <header>
          <nav id="scrollspy-nav" className="navbar navbar-custom navbar-top navbar-fixed-top sticky-navigation" >
            <div className="container">
              <div className="navbar-header">
                <button type="button" className="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                  <i className="fa fa-bars"></i>
                </button>
                <a className="navbar-brand nav-logo page-scroll" href="#page-top">
                  <img src={logoImg} alt="PiT Viet Nam"/>
                </a>
              </div>
              <div className="collapse navbar-collapse navbar-right navbar-main-collapse">
                <ul className="nav navbar-nav">
                  {navs.map(nav => <li key={nav.id}><a className="page-scroll" href={nav.id}>{nav.label}</a></li>)}
                </ul>
              </div>
            </div>
          </nav>
        </header>

        <section id="home" className={styles.home}>
          <div className="container">
            <div className="row relative">
              <Video
                src={homeScreenVideo}
                alt="Video showing the home screen, following a place, inviting friends"
                className={`${styles.introMobile} img-responsive`}
                slate={homeSlateImg}
              />
              <div className="col-md-6 col-md-offset-6">
                                  
                <h1><span className="bold">DỊCH VỤ IT OUTSOURCING</span></h1>
                <h1>Web Developer - Web Designer - Mobile App Developer - System Administrator - IT Training</h1>
                           
              </div>
            </div>
          </div>
        </section>

        <section id="intro" className="section overview">
          <div className="container">
            <div className="row">
              <div className="col-md-12" >
                <h4 className="bold">Chúng tôi là đội ngũ đam mê, có kinh nghiệm và chuyên môn trong lĩnh vực IT Outsourcing. Cam kết chất lượng dịch vụ tốt nhất cho Quý khách hàng là tôn chỉ số một của PiT Việt Nam. Chúng tôi tự tin với những thế mạnh của mình sẽ giúp Quý khách đạt được giá trị tối đa trong kinh doanh.</h4>
              </div>
              <div className="col-md-12">
                <div className="titleSection overview-title">
                  <h2>Chúng tôi có thể làm cho bạn</h2>
                  <div className="coloredLine"></div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="col-md-4" >
                <i className="bigIcon"><img src={web} alt=""/></i>
                <h4 className="bold">Website</h4>
                <p>Từ các trang web giá rẻ đến hệ thống Web App phức tạp với công nghệ mới nhất hiện nay</p>
              </div>

              <div className="col-md-4" >
                <i className="bigIcon"><img src={app} alt=""/></i>
                <h4 className="bold">Ứng dụng di động</h4>
                <p>Chúng tôi có thể làm cả native và hybrid app cho các hệ điều hành di động phổ biến</p>
              </div>

              <div className="col-md-4" >
                <i className="bigIcon"><img src={sysadmin} alt=""/></i>
                <h4 className="bold">Quản trị hệ thống</h4>
                <p>Giúp bạn quản trị Web, cài đặt, tối ưu cũng như khắc phục sự cố các dịch vụ trên server Linux</p>
              </div>
              

            </div>
          </div>
        </section>

        <section id="services1" className="section places">
          
            <div className="container">
              <a href="#" class="containerImg">
                <img src={webdesign} alt="webdesign"/>
              </a>
             
          </div>
        
        </section>

         <section id="services2" className="section places">
           <div className="container">
              <a href="#" class="containerImg">
                <img src={webadmin} alt="webadmin"/>
              </a>
         
          </div>
        </section>

        <section id="pricelist" className="section places">
           <div className="container">
              <a href="#" class="containerImg">
                <img src={webdesignPrice} alt="webdesignPrice"/>
              </a>
         
          </div>
        </section>

        <section id="projects" className="section places">
           <div className="container">
              <a href="#" class="containerImg">
                <img src={webdesignListDone} alt="webdesignListDone"/>
              </a>
         
          </div>
        </section>

        <section id="share" className="section share">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <h2><span className="bold">Chia sẻ cùng PiT Việt Nam</span></h2>
                <div id="shareIconsCountInside" className="shareIcons"></div>
              </div>
            </div>
          </div>
        </section>

        <section id="contact" className={`section ${styles.downloadSection}`}>
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="titleSection">
                  <h2>Xin chào <span className="bold">Quý khách</span></h2>
                  <h4>Hãy liên hệ với chúng tôi</h4>
                  <div className="coloredLine"></div>
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-md-5">
                <img className="img-responsive" src={piTVietNamContact} alt="PiT VietNam Contact" />
              </div>
              <div className="col-md-7">
                <form id="contactForm" className="contactForm">
                <div className="col-md-6 col-md-offset-3">
                  <input id="name" type="text" className="form-control" name="name" placeholder="Quý danh"/>
                  <input id="email" type="email" className="form-control" name="email" placeholder="Địa chỉ Email"/>
                  <textarea className="form-control" id="message" rows="5" placeholder="Tôi muốn thuê các bạn..."></textarea>

                  <div className="col-md-12">
                    <h4 className="success">
                      <i className="fa fa-check"></i> Lời nhắn quý khách đã gửi thành công.
                    </h4>
                    <h4 className="error">
                      <i className="fa fa-warning"></i> E-mail cần dài lớn hơn một ký tự.
                    </h4>
                  </div>

                  <button className="btn-new" type="submit" id="submit" name="submit">Gửi tin nhắn</button>
                </div>
              </form>
              </div>
            </div>
          </div>
        </section>

        

        <footer>
          <div className="container">
            <div className="col-md-12">
              <a href="#page-top" className="page-scroll"><img src={logoDarkImg} alt="PiT Viet Nam"/></a>
              <div className="space50"></div>
              <ul className="clearlist socialList">
                <li><a href="https://www.facebook.com/pitvietnam/"><i className="fa fa-facebook"></i><span className="hidden-xs">Facebook</span></a></li>
                <li><a href="https://twitter.com/gridbon"><i className="fa fa-twitter"></i><span className="hidden-xs">Twitter</span></a></li>
                <li><a href="https://www.linkedin.com/company-beta/13387797/"><i className="fa fa-linkedin"></i><span className="hidden-xs">LinkedIn</span></a></li>
                <li><a href="https://medium.com/@fulbrightnguyen"><i className="fa fa-medium"></i><span className="hidden-xs">Medium</span></a></li>
                {/* <li><a href="https://github.com/pitvietnam"><i className="fa fa-github"></i><span className="hidden-xs">github</span></a></li> */}
              </ul>
              <hr/>
              <p>2017 &copy; PiT&nbsp;Việt&nbsp;Nam.</p>
              <div className="star-text">*Thiết kế bởi Sen Việt - PiT Việt Nam.</div>
            </div>
          </div>
        </footer>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"/>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"/>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"/>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"/>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.appear/0.3.3/jquery.appear.min.js"/>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inview/1.0.0/jquery.inview.min.js"/>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"/>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pace/1.0.2/pace.min.js" />
        <script src="/jssocials.min.js"/>
        <script src={`/${this.props.assetsByChunkName.landing}`}/>
      </body>
    );
  }
}
